/**
 * 
 */
/**
 * @author user
 *
 */
module Day01 {
}