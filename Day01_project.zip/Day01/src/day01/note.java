package day01;

public class note {
	
	// main치고, ctrl+space -> 실행함수 생성
	public static void main(String[] args) {
		/*
		 * ctrl + f11 실행
		 * sysout치고, ctrl+space -> 출력문 자동완성
		 */
		System.out.println("Hello, Java");
		
	}
}
