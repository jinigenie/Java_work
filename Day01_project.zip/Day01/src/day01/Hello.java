package day01;

/**
 * 문서 주석 -> ex.class에 대한 정보
 * @author user
 *
 */
// main 입력하고, ctrl + space -> 실행함수 생성
public class Hello {
	public static void main(String[] args) {
		System.out.println("Hello, Java!"); // println은 줄바꿈
		System.out.println("안녕하세요\n");  // 문자열 안에서 \n도 줄바꿈
		System.out.print("반가워요");

		/*
		 * ctrl + f11 실행
		 * sysout 입력하고, ctrl + space -> 출력문 자동완성
		 * 
		 * 코드이동: alt + 방향키
		 * 코드복사(행복사): ctrl + alt + 방향키
		 * 한줄삭제: ctrl + d
		 * 전체정렬: ctrl + i
		 */
		
	}
}
