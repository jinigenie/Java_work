package day02;

public class Variable {
	public static void main(String[] args) {
		
		/*
		 * int: Integer로 정수 저장하는 타입
		 * String: 문자열을 저장하는 타입
		 */
		
		int num = 5; // 정수 변수 선언 및 초기화		
		System.out.println(num);
		
		String s = "홍길동"; // 문자열 타입은 클래스이므로 대문자로 시작
		System.out.println(s);
		
	}
}
