package day02;

public class Prac2 {
	public static void main(String[] args) {
		
		// 숫자로 시작 x 
//		int 4num = 10; // error
		
		// 카멜표기법
		int phoneNumber = 10;
		System.out.println(phoneNumber);

		// 키워드 포함 x
//		int class = 10 // error
		
	}
}
